-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 24, 2020 at 09:10 AM
-- Server version: 5.7.20
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_epharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `name`, `email`, `password`, `address`, `image`) VALUES
(1, 'Kaushal Kishore', 'admin', 'test', 'New Delhi', 'girl_avatar_child_kid-512.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banner`
--

CREATE TABLE IF NOT EXISTS `tbl_banner` (
  `id` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `p_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_banner`
--

INSERT INTO `tbl_banner` (`id`, `image`, `p_id`) VALUES
(65, 'download.jpeg', 3),
(66, 'banner1.jpg', 11),
(67, 'banner2.jpg', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `cart_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `p_quantity` int(11) NOT NULL,
  `total_price` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_catagories`
--

CREATE TABLE IF NOT EXISTS `tbl_catagories` (
  `category_id` int(11) NOT NULL,
  `cat_description` varchar(50) NOT NULL,
  `cat_title` varchar(30) NOT NULL,
  `cat_image` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_catagories`
--

INSERT INTO `tbl_catagories` (`category_id`, `cat_description`, `cat_title`, `cat_image`) VALUES
(1, 'Syrups images', 'Syrups', 'syrups.jpeg'),
(8, 'All tablets', 'Tablets', 'tablets.jpeg'),
(9, 'Capsules images', 'Capsules', 'capsules.jpeg'),
(10, 'Nutritions Products', 'Nutritions', 'nutritions.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_catagories_dietplans`
--

CREATE TABLE IF NOT EXISTS `tbl_catagories_dietplans` (
  `id` int(11) NOT NULL,
  `title` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_catagories_dietplans`
--

INSERT INTO `tbl_catagories_dietplans` (`id`, `title`) VALUES
(2, 'Diabetic Diet Plan '),
(8, 'Cancer Diet Plan'),
(9, 'BP Patient Diet Plan'),
(10, 'High Cholesterol Diet Plan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dietplan_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_dietplan_detail` (
  `id` int(11) NOT NULL,
  `breakfast_time` varchar(500) NOT NULL,
  `after_breakfast_time` varchar(50) NOT NULL,
  `lunch_time` varchar(50) NOT NULL,
  `dinner_time` varchar(50) NOT NULL,
  `afterdinner_time` varchar(30) NOT NULL,
  `diet_cat_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_dietplan_detail`
--

INSERT INTO `tbl_dietplan_detail` (`id`, `breakfast_time`, `after_breakfast_time`, `lunch_time`, `dinner_time`, `afterdinner_time`, `diet_cat_id`) VALUES
(3, 'Oats in Breakfast', 'Drink a glass of milk', 'Non spicy and fat free foods', 'Light dinner with pulses', 'Drink a class of milt', 10),
(4, 'Light and healthy breakfast', 'Drink a glass of milk', 'Fat and cholesterol free lunch', 'Light dinner with fruits', 'Take a glass of milk', 8),
(5, 'Sugar free breakfast', 'Sugar free milk', 'Bread and pulses', 'Sugar free light dinner', 'Drink a glass of milk', 2),
(6, 'Fat free breakfast', 'Drink a glass of milk', 'Fat free lunch', 'Fat free dinner', 'Drink a glass of milk', 9);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_labtest`
--

CREATE TABLE IF NOT EXISTS `tbl_labtest` (
  `id` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `title` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_labtest`
--

INSERT INTO `tbl_labtest` (`id`, `image`, `price`, `title`) VALUES
(3, 'urine.jpg', 400, 'Urine test'),
(4, 'blood.jpg', 300, 'Blood Glucose Test'),
(5, 'corona.jpg', 1000, 'Corona Test'),
(6, 'malaria.jpg', 400, 'Malaria Test');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_labtest_order`
--

CREATE TABLE IF NOT EXISTS `tbl_labtest_order` (
  `id` int(11) NOT NULL,
  `status` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `p_time` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_labtest_order`
--

INSERT INTO `tbl_labtest_order` (`id`, `status`, `price`, `user_id`, `p_time`) VALUES
(2, 'PACKED', 1200, 1, '1577469776910'),
(3, 'IN PROGRESS', 12000, 1, '1579779520842'),
(4, 'ON THE WAY', 400, 1, '1579790817175'),
(5, 'IN PROGRESS', 400, 1, '1598146534448'),
(6, 'IN PROGRESS', 400, 1, '1598256113868'),
(7, 'IN PROGRESS', 400, 1, '1598256839216');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pimages`
--

CREATE TABLE IF NOT EXISTS `tbl_pimages` (
  `image_id` int(11) NOT NULL,
  `image1` varchar(30) NOT NULL,
  `image2` varchar(30) NOT NULL,
  `image3` varchar(30) NOT NULL,
  `image4` varchar(30) NOT NULL,
  `p_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pimages`
--

INSERT INTO `tbl_pimages` (`image_id`, `image1`, `image2`, `image3`, `image4`, `p_id`) VALUES
(1, 'child.png', 'child.png', 'child.png', 'image4.jpg', 3),
(4, 'image1.jpg', 'image2.jpg', 'image3.jpg', 'image4.jpg', 4),
(5, 'image1.jpg', 'image2.jpg', 'image3.jpg', 'image4.jpg', 4),
(6, 'image1.jpg', 'image2.jpg', 'image3.jpg', 'image4.jpg', 4),
(8, 'image1.jpg', 'image2.jpg', 'image3.jpg', 'image4.jpg', 4),
(9, '763110.jpg', '763110.jpg', '763110.jpg', '', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prescription_order`
--

CREATE TABLE IF NOT EXISTS `tbl_prescription_order` (
  `id` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `p_time` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_prescription_order`
--

INSERT INTO `tbl_prescription_order` (`id`, `image`, `status`, `user_id`, `price`, `p_time`) VALUES
(1, 'p1.jpg', 'IN PROGRESS', 1, 0, '1579785808305'),
(2, 'p2.jpg', 'IN PROGRESS', 1, 0, '1579786083574'),
(3, 'p3.jpg', 'DELIVERED', 1, 220, '1579787097358'),
(4, 'p4.jpg', 'IN PROGRESS', 1, 0, '1598146407437');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE IF NOT EXISTS `tbl_products` (
  `p_id` int(11) NOT NULL,
  `p_title` varchar(30) NOT NULL,
  `p_description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `p_price` int(11) NOT NULL,
  `p_image` varchar(50) NOT NULL,
  `p_sale` int(11) NOT NULL,
  `p_quantity` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`p_id`, `p_title`, `p_description`, `category_id`, `p_price`, `p_image`, `p_sale`, `p_quantity`) VALUES
(3, 'Benadryl', 'While an occasional cough is normal, a cough that persists may be a sign of an underlying medical condition. Coughs are a defensive reflex that aims to clear excessive secretions and foreign bodies from airways. However, severe and frequent coughing can significantly impact your quality of life.\n\n', 1, 40, 's1.jpeg', 4, 6),
(11, 'Torex', 'While an occasional cough is normal, a cough that persists may be a sign of an underlying medical condition. Coughs are a defensive reflex that aims to clear excessive secretions and foreign bodies from airways. However, severe and frequent coughing can significantly impact your quality of life.\n\n', 1, 60, 's2.jpg', 0, 50),
(12, 'Supres', 'While an occasional cough is normal, a cough that persists may be a sign of an underlying medical condition. Coughs are a defensive reflex that aims to clear excessive secretions and foreign bodies from airways. However, severe and frequent coughing can significantly impact your quality of life.\n\n', 1, 99, 's3.jpg', 1, 1),
(13, 'Koflet', 'While an occasional cough is normal, a cough that persists may be a sign of an underlying medical condition. Coughs are a defensive reflex that aims to clear excessive secretions and foreign bodies from airways. However, severe and frequent coughing can significantly impact your quality of life.\n\n', 1, 77, 's4.jpg', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_order`
--

CREATE TABLE IF NOT EXISTS `tbl_product_order` (
  `id` int(11) NOT NULL,
  `status` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `p_time` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_order`
--

INSERT INTO `tbl_product_order` (`id`, `status`, `price`, `user_id`, `p_time`) VALUES
(1, 'PACKED', 0, 1, '1577466289909'),
(2, 'ON THE WAY', 100, 1, '1577469655729'),
(3, 'IN PROGRESS', 1132, 1, '1579117110539'),
(5, 'ON THE WAY', 1332, 1, '1579778754360'),
(6, 'DELIVERED', 500, 1, '1598145399872'),
(7, 'DELIVERED', 219, 1, '1598257031247');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `password`, `address`, `phone_no`, `image`) VALUES
(1, 'Amit Singh', 'amit@gmail.com', '123456', 'New Delhi', '9876543212', 'kaushal.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD UNIQUE KEY `p_id` (`p_id`);

--
-- Indexes for table `tbl_catagories`
--
ALTER TABLE `tbl_catagories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_catagories_dietplans`
--
ALTER TABLE `tbl_catagories_dietplans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_dietplan_detail`
--
ALTER TABLE `tbl_dietplan_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_labtest`
--
ALTER TABLE `tbl_labtest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_labtest_order`
--
ALTER TABLE `tbl_labtest_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pimages`
--
ALTER TABLE `tbl_pimages`
  ADD PRIMARY KEY (`image_id`),
  ADD UNIQUE KEY `image_id` (`image_id`);

--
-- Indexes for table `tbl_prescription_order`
--
ALTER TABLE `tbl_prescription_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tbl_product_order`
--
ALTER TABLE `tbl_product_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_catagories`
--
ALTER TABLE `tbl_catagories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_catagories_dietplans`
--
ALTER TABLE `tbl_catagories_dietplans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_dietplan_detail`
--
ALTER TABLE `tbl_dietplan_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_labtest`
--
ALTER TABLE `tbl_labtest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_labtest_order`
--
ALTER TABLE `tbl_labtest_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_pimages`
--
ALTER TABLE `tbl_pimages`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_prescription_order`
--
ALTER TABLE `tbl_prescription_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbl_product_order`
--
ALTER TABLE `tbl_product_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
