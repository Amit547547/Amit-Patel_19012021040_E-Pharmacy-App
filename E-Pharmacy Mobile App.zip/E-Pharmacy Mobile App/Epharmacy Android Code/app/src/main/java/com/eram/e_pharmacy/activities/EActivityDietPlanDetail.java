package com.eram.e_pharmacy.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.models.DietPlanDetail;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.Serializable;

public class EActivityDietPlanDetail extends AppCompatActivity {
    private String TAG = "TAG";
    private Serializable model;
    int dietCat_id;
    TextView tvDetailBreakfast,tvDetailAfterBreakfast,
            tvDetailLunchTime,tvDetailDinnerTime,
            tvDetailAfterDinnerTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_plan_deatil);
        try {
            tvDetailBreakfast=findViewById(R.id.tvDetailBreakfast);
            tvDetailAfterBreakfast=findViewById(R.id.tvDetailAfterBreakfast);
            tvDetailLunchTime=findViewById(R.id.tvDetailLunchTime);
            tvDetailDinnerTime=findViewById(R.id.tvDetailDinnerTime);
            tvDetailAfterDinnerTime=findViewById(R.id.tvDetailAfterDinnerTime);
            Intent i = getIntent();
            dietCat_id=i.getIntExtra(ECONSTANT.CATID,-1);
            setDetailOfDietPlans();
        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }

    }

    private void setDetailOfDietPlans() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_MASTERDTAIL_DIETPLAN + dietCat_id,
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response);
                            final Gson gson = new Gson();
                            try
                            {
                                DietPlanDetail[] models = gson.fromJson(String.valueOf(
                                        response.getJSONArray("data")),
                                        DietPlanDetail[].class);
                                tvDetailBreakfast.setText(models[0].getBreakfast_time());
                                tvDetailAfterBreakfast.setText(models[0].getAfter_breakfast_time());
                                tvDetailLunchTime.setText(models[0].getLunch_time());
                                tvDetailDinnerTime.setText(models[0].getDinner_time());
                                tvDetailAfterDinnerTime.setText(models[0].getAfterdinner_time());

                            }catch (Exception e){
                                Log.e(TAG, "onResponse: "+e.toString() );
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);

        } catch (Exception e) {
            Log.e(TAG, "setDetailOfDietPlans: " + e.toString());
        }
    }
}
