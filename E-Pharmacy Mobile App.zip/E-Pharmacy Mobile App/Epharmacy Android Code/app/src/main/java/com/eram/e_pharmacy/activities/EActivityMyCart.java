package com.eram.e_pharmacy.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.adapters.EAdapterCArtProducts;
import com.eram.e_pharmacy.models.GetCartItems;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONObject;

public class EActivityMyCart extends AppCompatActivity {
    public static ListView lvAddedToCartProducts;
    public static String TAG = "TAG";
    private  int price;
    public static EAdapterCArtProducts adapterProduct;
    public static TextView tvCartTotalPrice;
    public static TextView tvCartFinalTotalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_cart);
        try {
            tvCartTotalPrice = findViewById(R.id.tvCartTotalPrice);
            tvCartFinalTotalPrice = findViewById(R.id.tvCartFinalTotalPrice);
            lvAddedToCartProducts = findViewById(R.id.lvCartProducts);

            (findViewById(R.id.btnAddToCArt)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(EActivityMyCart.this, EActivityOrderDeliveryDetail.class);
                    intent.putExtra(ECONSTANT.TOTAL_PRICE,price);
                    intent.putExtra(ECONSTANT.KEY_ORDER_TYPE,ECONSTANT.ORDER_TYPE_CART);

                   // intent.putExtra(String.valueOf(ECONSTANT.ORDER_TYPE_CART), price);
                    startActivity(intent);
                    finish();
                }
            });
            getCartProducts();
        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }
    }


    public void getCartProducts() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_GET_CART + ECONSTANT.logedUser.getId(), null,
                    new Response.Listener<JSONObject>() {


                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            try {
                                if (response.getBoolean("status")) {
                                    GetCartItems[] models = gson.fromJson(String.valueOf(
                                            response.getJSONArray("data"))
                                            , GetCartItems[].class);
                                    adapterProduct = new
                                            EAdapterCArtProducts(EActivityMyCart.this,
                                            models);

                                    adapterProduct.notifyDataSetChanged();
                                    lvAddedToCartProducts.setAdapter(adapterProduct);
                                    price=0;
                                    for(int i=0;i<models.length;i++){
                                      price= price+ models[i].getTotal_price();
                                    }
                                    tvCartTotalPrice.setText("Rs."+price);
                                    tvCartFinalTotalPrice.setText("Rs."+price);
                                } else {
                                    ((RelativeLayout)findViewById(R.id.rlCartData)).setVisibility(View.GONE);
                                    ((RelativeLayout)findViewById(R.id.rlCartEmpty)).setVisibility(View.VISIBLE);

                                }
                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "getdatafromcart: " + e.toString());
        }
    }
}
