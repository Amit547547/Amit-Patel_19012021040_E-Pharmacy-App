package com.eram.e_pharmacy.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.models.LabTestDetail;
import com.eram.e_pharmacy.utilities.ECONSTANT;

public class EAdapterLabTest extends ArrayAdapter<LabTestDetail> {
    Context context;

    public EAdapterLabTest(@NonNull Context context, LabTestDetail[] user) {
        super(context, 0, user);
        this.context = context;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View userView = convertView;
        if (convertView == null) {
            userView = LayoutInflater.from(context).inflate(R.layout.single_row_labtest,
                    parent, false);
        }
        LabTestDetail user = getItem(position);

     ImageView ivcat = userView.findViewById(R.id.ivLabTest);
        TextView tvtitle = userView.findViewById(R.id.tvLabTestTitle);
        TextView tvprice = userView.findViewById(R.id.tvLabTestPrice);
        Glide.with(context).load(ECONSTANT
                .URL_IMG_LABTESTS + user.getImage()).into(ivcat);
        tvtitle.setText(user.getTitle());
        tvprice.setText(String.valueOf("Rs."+user.getPrice()));
        return userView;

    }
}
