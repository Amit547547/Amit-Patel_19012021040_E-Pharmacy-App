package com.eram.e_pharmacy.models;

public class CountCOP {
    int p_id, pre_id, l_id;

    public CountCOP(int p_id, int pre_id, int l_id) {
        this.p_id = p_id;
        this.pre_id = pre_id;
        this.l_id = l_id;
    }

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public int getPre_id() {
        return pre_id;
    }

    public void setPre_id(int pre_id) {
        this.pre_id = pre_id;
    }

    public int getL_id() {
        return l_id;
    }

    public void setL_id(int l_id) {
        this.l_id = l_id;
    }
}
