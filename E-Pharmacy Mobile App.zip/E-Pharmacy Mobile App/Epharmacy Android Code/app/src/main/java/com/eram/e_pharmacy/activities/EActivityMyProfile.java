package com.eram.e_pharmacy.activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.bumptech.glide.Glide;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.models.CountCOP;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class EActivityMyProfile extends AppCompatActivity {
    private static final String TAG = "TAG";
    private ImageView ivProfile;
    private TextView tvName, tvEmail, tvPhoneNo, tvAddress, tvCountLabTest, tvCountPrescription, tvCountProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        try {
            ivProfile = findViewById(R.id.ivProfile);
            tvName = findViewById(R.id.tvName);
            tvEmail = findViewById(R.id.tvEmail);
            tvPhoneNo = findViewById(R.id.tvPhoneNo);
            tvAddress = findViewById(R.id.tvAddress);
            tvCountLabTest = findViewById(R.id.tvCountLabTest);
            tvCountPrescription = findViewById(R.id.tvCountPrescription);
            tvCountProducts = findViewById(R.id.tvCountProducts);

            tvName.setText(ECONSTANT.logedUser.getName());
            tvEmail.setText(ECONSTANT.logedUser.getEmail());
            tvPhoneNo.setText(ECONSTANT.logedUser.getPhone_no());
            tvAddress.setText(ECONSTANT.logedUser.getAddress());
            Glide.with(this).load(
                    ECONSTANT.URL_IMG_USER + ECONSTANT.logedUser.getImage())
                    .into(ivProfile);
            getCountCOP();
        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }
    }

    private void getCountCOP() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_COUNT_COP + ECONSTANT.logedUser.getId(),
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            Gson gson = new Gson();
                            try {
                                CountCOP[] pres = gson.fromJson(String.valueOf(
                                        response.getJSONArray("pre")), CountCOP[].class);
                                CountCOP[] product = gson.fromJson(String.valueOf(
                                        response.getJSONArray("pro")), CountCOP[].class);
                                CountCOP[] lab = gson.fromJson(String.valueOf(
                                        response.getJSONArray("lab")), CountCOP[].class);
                                tvCountPrescription.setText(String.valueOf(pres[0].getPre_id()));
                                tvCountProducts.setText(String.valueOf(product[0].getP_id()));
                                tvCountLabTest.setText(String.valueOf(lab[0].getL_id()));
                            } catch (JSONException e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }

            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "getCountCOP: " + e.toString());
        }
    }
}
