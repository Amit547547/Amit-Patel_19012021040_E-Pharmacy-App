package com.eram.e_pharmacy.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.models.DietPlanCategory;

public class EAdapterDietPlans extends ArrayAdapter<DietPlanCategory> {
    Context context;

    public EAdapterDietPlans(@NonNull Context context, DietPlanCategory[] user) {
        super(context, 0,user);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
       View userView = convertView;
       if(convertView==null)
       {
           userView = LayoutInflater.from(context).inflate(R.layout.single_row_diet_plans,
                   parent,false);
       }

        DietPlanCategory user=getItem(position);
        TextView tvtitle=userView.findViewById(R.id.DietCatTitle);
        tvtitle.setText(user.getTitle());
        return userView;
    }
}
