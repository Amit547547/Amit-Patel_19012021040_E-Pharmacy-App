package com.eram.e_pharmacy.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.bumptech.glide.Glide;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.activities.EActivityMyCart;
import com.eram.e_pharmacy.models.GetCartItems;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;

import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class EAdapterCArtProducts extends ArrayAdapter<GetCartItems> {
    private static final String TAG = "TAG";
    private Context context;
    public static int totalPrice;

    public EAdapterCArtProducts(@NonNull Context context, GetCartItems[] user) {
        super(context, 0, user);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.sinlge_row_cart, parent, false);

        }
        final GetCartItems cartItems = getItem(position);
        (view.findViewById(R.id.IbDelete)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Toast.makeText(context, "" + cartItems.getCart_id(), Toast.LENGTH_SHORT).show();
                    new SweetAlertDialog(context, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("Are you sure You want to delete")
                            .setContentText("If you do so, there's no getting back it")
                            .setConfirmButton("Yes", new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    sweetAlertDialog.dismissWithAnimation();
                                    deleteCartItem(cartItems.getCart_id());


                                }
                            })
                            .setCancelButton("No", new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    sweetAlertDialog.dismissWithAnimation();
                                }
                            }).show();

                } catch (Exception e) {
                    Log.e(TAG, "onClick: " + e.toString());
                }
            }
        });
        TextView tvname = view.findViewById(R.id.tvCTitle);
        final TextView tvprice = view.findViewById(R.id.tvCPrice);
        final TextView tvtotalprice = view.findViewById(R.id.tvCTotalPrice);
        final TextView tvCQuantity = view.findViewById(R.id.tvCQuantity);
        tvname.setText(cartItems.getP_title());
        Log.e(TAG, "getView: ->>>" + cartItems.getP_price() * cartItems.getP_quantity());

       // totalPrice = totalPrice + cartItems.getP_price() * cartItems.getP_quantity();
         tvprice.setText(("Rs." + cartItems.getP_price()));
        tvCQuantity.setText(("Qty." + cartItems.getP_quantity()));
        tvtotalprice.setText(("Rs." +cartItems.getTotal_price()));
        ImageView ivCArtProducts = view.findViewById(R.id.ivCProduct);
        Glide.with(context).load(ECONSTANT.URL_IMG_SUBCATAGORY + cartItems.getP_image()).into(ivCArtProducts);

        return view;
    }

    private void deleteCartItem(int cart_id) {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,
                    ECONSTANT.URL_DEL_CARTITEM + cart_id,
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response);
                            ((EActivityMyCart) context).finish();
                            context.startActivity(new Intent(context, EActivityMyCart.class));
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(context).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "deleteCartItem: " + e.toString());
        }
    }
}
