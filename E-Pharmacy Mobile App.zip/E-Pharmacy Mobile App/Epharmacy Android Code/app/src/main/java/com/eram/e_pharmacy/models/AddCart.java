package com.eram.e_pharmacy.models;

public class AddCart {
   private int cart_id,p_id,user_id,p_quantity,p_status;

    public AddCart(int cart_id, int p_id, int user_id, int p_quantity, int p_status) {
        this.cart_id = cart_id;
        this.p_id = p_id;
        this.user_id = user_id;
        this.p_quantity = p_quantity;
        this.p_status = p_status;
    }

    public int getCart_id() {
        return cart_id;
    }

    public void setCart_id(int cart_id) {
        this.cart_id = cart_id;
    }

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getP_quantity() {
        return p_quantity;
    }

    public void setP_quantity(int p_quantity) {
        this.p_quantity = p_quantity;
    }

    public int getP_status() {
        return p_status;
    }

    public void setP_status(int p_status) {
        this.p_status = p_status;
    }
}
