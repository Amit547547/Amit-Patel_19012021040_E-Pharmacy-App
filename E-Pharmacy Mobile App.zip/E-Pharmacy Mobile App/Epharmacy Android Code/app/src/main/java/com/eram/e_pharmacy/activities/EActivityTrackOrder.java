package com.eram.e_pharmacy.activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.eram.e_pharmacy.R;

public class EActivityTrackOrder extends AppCompatActivity {
    private static final String TAG = "TAG";
    private TextView tvOrderStatus;
    private Button btnSubmitReview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking);
        try {
            btnSubmitReview = findViewById(R.id.btnSubmitReview);
            tvOrderStatus = findViewById(R.id.tvOrderStatus);
            String s = getIntent().getStringExtra("STATUS");
            tvOrderStatus.setText(s);
            switch (s) {
                case "IN PROGRESS": {
                    ((LottieAnimationView) findViewById(R.id.anim_view_status)).setAnimation(R.raw.in_progress);
                }
                break;
                case "PACKED": {
                    ((LottieAnimationView) findViewById(R.id.anim_view_status)).setAnimation(R.raw.packed);
                }
                break;
                case "ON THE WAY": {
                    ((LottieAnimationView) findViewById(R.id.anim_view_status)).setAnimation(R.raw.on_the_way);
                }
                break;
                case "DELIVERED": {
                    ((LottieAnimationView) findViewById(R.id.anim_view_status)).setAnimation(R.raw.delievered);
                }
                break;
            }


        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());

        }
    }
}
