package com.eram.e_pharmacy.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.bumptech.glide.Glide;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.models.LabTestDetail;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.Serializable;

public class EActivityLabTestDetail extends AppCompatActivity {
    private String TAG = "TAG";
    private int labtest_id,price;
    private ImageView ivlabtest;
    private Button btnBookLabTest;
    private LabTestDetail[] labTestDetails;
    private TextView tvLabTestPrice, tvLabTestTitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_test_detail);
        try {
            ivlabtest=findViewById(R.id.ivMDLabTest);
            tvLabTestTitle = findViewById(R.id.tvMDLabTestTitle);
            tvLabTestPrice = findViewById(R.id.tvMDLabTestPrice);
            btnBookLabTest=findViewById(R.id.btnBookLabTest);
            Intent i = getIntent();
            labtest_id=i.getIntExtra(ECONSTANT.LABTEST_ID,-1);
            getsingleproduct();
            btnBookLabTest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                 Intent intent=new Intent(EActivityLabTestDetail.this,
                       EActivityOrderDeliveryDetail.class);
                 intent.putExtra(ECONSTANT.TOTAL_PRICE, labTestDetails[0].getPrice());
                 intent.putExtra(ECONSTANT.KEY_ORDER_TYPE,ECONSTANT.ORDER_TYPE_LABTEST);
                 startActivity(intent);
                 finish();
                }
            });
        }catch (Exception e)
        {
            Log.e(TAG, "onCreate: "+e.toString() );
        }

    }
    private void getsingleproduct() {
        try {
            JsonObjectRequest objectRequest =
                    new JsonObjectRequest(Request.Method.GET,
                            ECONSTANT.URL_LAB_TEST_DETAIL + labtest_id,
                            null, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            try {
                                labTestDetails = gson.fromJson(String.valueOf(
                                        response.getJSONArray("data")),
                                        LabTestDetail[].class);
                                Glide.with(EActivityLabTestDetail.this).load(ECONSTANT
                                        .URL_IMG_LABTESTS + labTestDetails[0].getImage()).into(ivlabtest);
                                tvLabTestPrice.setText(String.valueOf(labTestDetails[0].getPrice()));
                                tvLabTestTitle.setText(labTestDetails[0].getTitle());

                            } catch (Exception ex) {
                                Log.e(TAG, "onResponse:Exception " + ex.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e(TAG, "onErrorResponse: " + error.toString());
                        }
                    });
            MyNetwork.getInstance(this).addToRequestQueue(objectRequest);

        } catch (Exception e) {
            Log.e(TAG, "EXP :" + e.toString());
        }
    }
}
