package com.eram.e_pharmacy.models;

public class GetCartItems {
    private int cart_id, p_price, p_sale, p_quantity, total_price;
    private String p_title, p_image;

    public GetCartItems(int cart_id, int p_price, int p_sale, int p_quantity, int total_price, String p_title, String p_image) {
        this.cart_id = cart_id;
        this.p_price = p_price;
        this.p_sale = p_sale;
        this.p_quantity = p_quantity;
        this.total_price = total_price;
        this.p_title = p_title;
        this.p_image = p_image;
    }

    public int getTotal_price() {
        return total_price;
    }

    public void setTotal_price(int total_price) {
        this.total_price = total_price;
    }

    public int getCart_id() {
        return cart_id;
    }

    public void setCart_id(int cart_id) {
        this.cart_id = cart_id;
    }

    public int getP_price() {
        return p_price;
    }

    public void setP_price(int p_price) {
        this.p_price = p_price;
    }

    public int getP_sale() {
        return p_sale;
    }

    public void setP_sale(int p_sale) {
        this.p_sale = p_sale;
    }

    public int getP_quantity() {
        return p_quantity;
    }

    public void setP_quantity(int p_quantity) {
        this.p_quantity = p_quantity;
    }

    public String getP_title() {
        return p_title;
    }

    public void setP_title(String p_title) {
        this.p_title = p_title;
    }

    public String getP_image() {
        return p_image;
    }

    public void setP_image(String p_image) {
        this.p_image = p_image;
    }
}

