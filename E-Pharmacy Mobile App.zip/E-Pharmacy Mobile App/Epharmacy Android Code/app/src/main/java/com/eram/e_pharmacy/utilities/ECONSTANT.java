package com.eram.e_pharmacy.utilities;

import com.eram.e_pharmacy.models.User;

public class ECONSTANT {

    public static User logedUser;
    public static final String TAG = "TAG";
    private static final String IP = "http://192.168.1.103/";
    private static final String BASE_URL = IP + "epharmacy/";
    private static final String BASE_IMAGE_URL = IP + "epharmacy/";
    public static final String KEY_ORDER_TYPE = "KEY_ORDER_TYPE";
    public static final String KEY_PRODUCT_ID = "KEY_PRODUCT_ID";
    public static final String CATID = "CATID";
    public static final String LABTEST_ID = "LABTEST_ID";
    public static final String TOTAL_PRICE = "TOTAL_PRICE";
    public static final String CAT_ID_KEY = "CAT_ID_KEY";
    public static final String KEY_LOGED_USER = "KEY_LOGED_USER";

    public static final String URL_SIGNUP = BASE_URL + "signup.php";
    public static final String URL_IMG_CATAGORY = BASE_IMAGE_URL + "images/Catagory/";
    public static final String URL_IMG_PRESCRIPTIION = BASE_IMAGE_URL + "images/prescription/";
    public static final String URL_IMG_USER = BASE_IMAGE_URL + "images/user/";
    public static final String URL_LOGIN = BASE_URL + "login.php";
    public static final String URL_ADD_TO_ORDERS = BASE_URL + "EAddProductOrder.php";

    public static final String URL_IMG_PRODUCTS = BASE_IMAGE_URL + "images/Products/";
    public static final String URL_IMG_BANNERS = BASE_IMAGE_URL + "images/banners/";
    public static final String URL_IMG_LABTESTS = BASE_IMAGE_URL + "images/LabTest/";
    public static final String URL_IMG_SUBCATAGORY = BASE_IMAGE_URL + "images/Products/";
    public static final String URL_CATAGORIES = BASE_URL + "ECatagory.php";
    public static final String URL_DELETE_CARTBY_ID = BASE_URL + "EDeleteCartById.php?user_id=";

    public static final String URL_EPRODUCTSBYSUBCATID = BASE_URL + "EProductsBySubCatId.php?cid=";
    public static final String URL_GET_BANNER = BASE_URL + "EGetBanner.php";
    public static final String URL_GET_PRESCRIPTION_ORDER = BASE_URL + "GetFromTblOrdersPrescription.php?user_id=";
    public static final String URL_GET_PRODUCT_ORDER = BASE_URL + "EGetProductOrders.php?user_id=";
    public static final String URL_GET_LABTEST_ORDER = BASE_URL + "EGetLAbTestOrders.php?user_id=";
    public static final String URL_ADD_TO_LABTEST_ORDER = BASE_URL + "EAddLabTestOrders.php";
    public static final String URL_LAB_TEST = BASE_URL + "ELabTest.php";
    public static final String URL_LAB_TEST_DETAIL = BASE_URL + "MasterDetailLabTestById.php?labtest_id=";
    public static final String URL_PRESCRIPTION_ORDER = BASE_URL + "EPrescription_order.php";
    public static final String URL_DIETcAATGORIES_ECOM = BASE_URL + "EDietCatagories.php";
    public static final String URL_MASTERDTAIL_PRODUCTS_ECOM = BASE_URL + "EMasterDeailProducts.php?p_id=";
    public static final String URL_MASTERDTAIL_DIETPLAN = BASE_URL + "DietPlanDetailByCatId.php?dietCat_id=";
    public static final String URL_ADDTOCAR = BASE_URL + "EAddToCArt.php?id=";
    public static final String URL_COUNT_COP = BASE_URL + "ECountCOP.php?user_id=";
    public static final String URL_GET_CART = BASE_URL + "EGetCart.php?user_id=";
    public static final String URL_DEL_CARTITEM = BASE_URL + "EDeleteCartItem.php?cart_id=";

    public static int cid = 0, id;
    public static final int ORDER_TYPE_CART = 0;
    public static final int ORDER_TYPE_LABTEST = 1;
    public static final int ORDER_TYPE_PRESCRIPTION = 2;
}
