package com.eram.e_pharmacy.models;

public class DietPlanDetail {
    int id,diet_cat_id;
   private String breakfast_time,after_breakfast_time,lunch_time,dinner_time,afterdinner_time;

    public DietPlanDetail(int id, int diet_cat_id, String breakfast_time, String after_breakfast_time, String lunch_time, String dinner_time, String afterdinner_time) {
        this.id = id;
        this.diet_cat_id = diet_cat_id;
        this.breakfast_time = breakfast_time;
        this.after_breakfast_time = after_breakfast_time;
        this.lunch_time = lunch_time;
        this.dinner_time = dinner_time;
        this.afterdinner_time = afterdinner_time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDiet_cat_id() {
        return diet_cat_id;
    }

    public void setDiet_cat_id(int diet_cat_id) {
        this.diet_cat_id = diet_cat_id;
    }

    public String getBreakfast_time() {
        return breakfast_time;
    }

    public void setBreakfast_time(String breakfast_time) {
        this.breakfast_time = breakfast_time;
    }

    public String getAfter_breakfast_time() {
        return after_breakfast_time;
    }

    public void setAfter_breakfast_time(String after_breakfast_time) {
        this.after_breakfast_time = after_breakfast_time;
    }

    public String getLunch_time() {
        return lunch_time;
    }

    public void setLunch_time(String lunch_time) {
        this.lunch_time = lunch_time;
    }

    public String getDinner_time() {
        return dinner_time;
    }

    public void setDinner_time(String dinner_time) {
        this.dinner_time = dinner_time;
    }

    public String getAfterdinner_time() {
        return afterdinner_time;
    }

    public void setAfterdinner_time(String afterdinner_time) {
        this.afterdinner_time = afterdinner_time;
    }
}
