package com.eram.e_pharmacy.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

import cn.pedant.SweetAlert.SweetAlertDialog;

import static com.eram.e_pharmacy.activities.EActivityUploadPrescription.photo;
import static com.eram.e_pharmacy.activities.EActivityUploadPrescription.selectedImage;
import static com.eram.e_pharmacy.adapters.EAdapterCArtProducts.totalPrice;

public class EActivityOrderDeliveryDetail extends AppCompatActivity {

    int price;
    public static String name, email, address, phone;
    private TextView etODDetailName,tvOPrice, etODDetailEmail, etODDetailContact, etODDetailAddress;
    private static ImageView ivODDetail;
    private static final String TAG = "TAG";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipping_detail);
        try {
            Intent i = getIntent();
            price = i.getIntExtra(ECONSTANT.TOTAL_PRICE, -1);

            final int orderType = i.getIntExtra(ECONSTANT.KEY_ORDER_TYPE, -1);
            etODDetailName = findViewById(R.id.etODDetailName);
            etODDetailEmail = findViewById(R.id.etODDetailEmail);
            etODDetailContact = findViewById(R.id.etODDetailContact);
            etODDetailAddress = findViewById(R.id.etODDetailAddress);
            ivODDetail = findViewById(R.id.ivODDetail);
            tvOPrice = findViewById(R.id.tvOPrice);
            if (price!= -1) {
                tvOPrice.setText(String.valueOf(price));
            }
            else {
                tvOPrice.setText("Price will calculated after review Prescription");
                tvOPrice.setTextSize(14f);
            }
            etODDetailName.setText(ECONSTANT.logedUser.getName());
            etODDetailEmail.setText(ECONSTANT.logedUser.getEmail());
            etODDetailContact.setText(ECONSTANT.logedUser.getPhone_no());
            etODDetailAddress.setText(ECONSTANT.logedUser.getAddress());
            if (selectedImage == null) {
                ivODDetail.setImageBitmap(photo);
                selectedImage = null;
                phone = null;

            } else {
                ivODDetail.setImageURI(selectedImage);
                selectedImage = null;
                phone = null;
            }

            findViewById(R.id.btnConfirmOrder).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                      if (orderType == ECONSTANT.ORDER_TYPE_CART) {
                            Log.e(TAG, "onCreate: ----> Order From Cart");
                            JSONObject testModel = new JSONObject();
                            try {
                                testModel.put("status", "IN PROGRESS");
                                testModel.put("price", price);
                                testModel.put("user_id", ECONSTANT.logedUser.getId());
                                testModel.put("p_time", System.currentTimeMillis());
                                addProductToOrders(testModel);

                            } catch (JSONException e) {
                                Log.e(TAG, "onClick: " + e.toString());
                            }

                        } else if (orderType == ECONSTANT.ORDER_TYPE_LABTEST) {
                            Log.e(TAG, "onCreate: ----> Order From LabTest");
                            JSONObject testModel = new JSONObject();
                            try {
                                testModel.put("status", "IN PROGRESS");
                                testModel.put("price", price);
                                testModel.put("user_id", ECONSTANT.logedUser.getId());
                                testModel.put("p_time", System.currentTimeMillis());
                                addToLabTestOrder(testModel);

                            } catch (JSONException e) {
                                Log.e(TAG, "onClick: " + e.toString());
                            }
                        } else if (orderType == ECONSTANT.ORDER_TYPE_PRESCRIPTION) {
                            new MyTask().execute();
                        }
                    } catch (Exception ex) {
                        Log.e(TAG, "onClick: " + ex.toString());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }
    }

    private void addToLabTestOrder(JSONObject testModel) {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,
                    ECONSTANT.URL_ADD_TO_LABTEST_ORDER,
                    testModel,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: --" + response);
                            try {
                                if (response.getBoolean("data")) {
                                    new SweetAlertDialog(EActivityOrderDeliveryDetail.this,
                                            SweetAlertDialog.SUCCESS_TYPE)
                                            .setTitleText("Good job!")
                                            .setContentText("Order Place Successfully!")
                                            .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                                @Override
                                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                                    startActivity(new Intent(EActivityOrderDeliveryDetail.this,
                                                            EActivityMyOrders.class));
                                                    finish();
                                                }
                                            }).show();
                                } else {
                                    new SweetAlertDialog(EActivityOrderDeliveryDetail.this,
                                            SweetAlertDialog.ERROR_TYPE)
                                            .setTitleText("OOPS.!")
                                            .setContentText("Some Error Occurs Try Again!")
                                            .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                                @Override
                                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                                    startActivity(new Intent(EActivityOrderDeliveryDetail.this,
                                                            EActivityMyOrders.class));
                                                    totalPrice = 0;
                                                    finish();
                                                }
                                            }).show();
                                }
                            } catch (JSONException e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e(TAG, "onErrorResponse: " + error.toString());
                        }
                    });
            MyNetwork.getInstance(EActivityOrderDeliveryDetail.this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "addToLabTestOrder: " + e.toString());
        }
    }

    public class MyTask extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.e(TAG, "onPreExecute: ");

        }

        @Override
        protected String doInBackground(Void... uris) {
            try {
                Bitmap selectedImage = ((BitmapDrawable) ivODDetail.getDrawable()).getBitmap();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                selectedImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] b = baos.toByteArray();
                String base64String = Base64.encodeToString(b, Base64.DEFAULT);
                Log.e(TAG, "doInBackground: ");
                return base64String;

            } catch (Exception e) {
                Log.e(TAG, "doInBackground: EXP" + e.toString());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (null != result) {
                Log.e(TAG, "onPostExecute:  " + result);
                JSONObject testModel = new JSONObject();
                try {
                    testModel.put("image", result);
                    testModel.put("status", "IN PROGRESS");
                    testModel.put("price", 0);
                    testModel.put("user_id", ECONSTANT.logedUser.getId());
                    testModel.put("p_time", System.currentTimeMillis());
                    Log.e(TAG, "onPostExecute: " + result);
                    addToPrescriptionOrders(testModel);

                } catch (JSONException e) {
                    Log.e(TAG, "onPostExecute: " + e.toString());
                }
            }
        }
    }

    private void addToPrescriptionOrders(JSONObject jsonObject) {
        try {
            JsonObjectRequest json = new JsonObjectRequest(Request.Method.POST,
                    ECONSTANT.URL_PRESCRIPTION_ORDER,
                    jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                if (response.getBoolean("data")) {
                                    Log.e(TAG, "onResponse: "+response.toString());
                                    new SweetAlertDialog(EActivityOrderDeliveryDetail.this,
                                            SweetAlertDialog.SUCCESS_TYPE)
                                            .setTitleText("Success!")
                                            .setContentText("Order placed Successfully!")
                                            .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                                @Override
                                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                                    startActivity(new Intent(EActivityOrderDeliveryDetail.this,
                                                            EActivityMyOrders.class));
                                                    totalPrice = 0;
                                                    finish();
                                                }
                                            }).show();
                                } else {
                                    new SweetAlertDialog(EActivityOrderDeliveryDetail.this, SweetAlertDialog.ERROR_TYPE)
                                            .setTitleText("Oops...")
                                            .setContentText("Could not place Order!")
                                            .show();
                                }
                            } catch (JSONException e) {

                                Log.e(TAG, "onResponse: EXP: " + e.toString());
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e(TAG, "onErrorResponse: "+error.toString());
                            new SweetAlertDialog(EActivityOrderDeliveryDetail.this, SweetAlertDialog.ERROR_TYPE)
                                    .setTitleText("Oops...")
                                    .setContentText(error.toString())
                                    .show();                   }
                    });
            MyNetwork.getInstance(this).addToRequestQueue(json);
        } catch (Exception e) {
            Log.e(TAG, "getfromorderdeatil: " + e.toString());
        }
    }

    private void addProductToOrders(JSONObject testModel) {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,
                    ECONSTANT.URL_ADD_TO_ORDERS,
                    testModel,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            try {
                                if (!response.getBoolean("data")) {
                                    new SweetAlertDialog(EActivityOrderDeliveryDetail.this, SweetAlertDialog.ERROR_TYPE)
                                            .setTitleText("Oops...")
                                            .setContentText("Could not place Order!")
                                            .show();
                                } else {
                                    deleteCartById();
                                    new SweetAlertDialog(EActivityOrderDeliveryDetail.this, SweetAlertDialog.SUCCESS_TYPE)
                                            .setTitleText("Success!")
                                            .setContentText("Order Placed Successfully.")
                                            .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                                @Override
                                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                                    startActivity(new Intent(EActivityOrderDeliveryDetail.this,
                                                            EActivityMyOrders.class));
                                                    totalPrice = 0;
                                                    finish();
                                                }
                                            })
                                            .show();
                                }
                            } catch (JSONException e) {
                                Log.e(TAG, "onResponse: EXP: " + e.toString());
                            }

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "addProductToOrders: " + e.toString());
        }
    }

    private void deleteCartById() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,
                    ECONSTANT.URL_DELETE_CARTBY_ID + ECONSTANT.logedUser.getId(),
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "deleteCartById: " + e.toString());
        }
    }

}
