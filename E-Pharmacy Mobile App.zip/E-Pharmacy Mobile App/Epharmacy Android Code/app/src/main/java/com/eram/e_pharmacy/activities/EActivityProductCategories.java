package com.eram.e_pharmacy.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.appizona.yehiahd.fastsave.FastSave;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.adapters.EAdapterCategory;
import com.eram.e_pharmacy.adapters.EAdapterProduct;
import com.eram.e_pharmacy.models.Category;
import com.eram.e_pharmacy.models.Product;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONObject;

public class EActivityProductCategories extends AppCompatActivity {
    private ListView lvCatagories;
    private GridView gvSubCategory;
    private EAdapterCategory eAdapterCategory;
    private LottieAnimationView pgcatagory;
    private EAdapterProduct adapterProduct;
    private String TAG = "TAG";
    private int product_id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_categories);
        try {

            gvSubCategory = findViewById(R.id.gvSubCategory);
            lvCatagories = findViewById(R.id.lvCatagories);
            pgcatagory = findViewById(R.id.pgcatagory);
            getdatafromcatagory();
            FastSave.getInstance().saveInt(ECONSTANT.CAT_ID_KEY, product_id);

            gvSubCategory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Product model = adapterProduct.getItem(position);
                    product_id = model.getP_id();
                    Log.e(TAG, "onItemClick:  " + model.getP_id());
                    Intent intent = new Intent(EActivityProductCategories.this,
                            EActivityProductDetail.class);
                    intent.putExtra(ECONSTANT.KEY_PRODUCT_ID, product_id);
                    startActivity(intent);
                }
            });



        } catch (Exception e) {

            Log.e(TAG, "onCreate: " + e.toString());
        }
    }

    private void getdatafromProducts(int id) {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                    Request.Method.GET
                    , ECONSTANT.URL_EPRODUCTSBYSUBCATID + id, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            pgcatagory.setVisibility(View.INVISIBLE);
                            try {
                                if (response.getBoolean("status")) {
                                    Product[] models =
                                            gson.fromJson(String.valueOf(
                                                    response.getJSONArray("data")),
                                                    Product[].class);
                                    adapterProduct = new
                                            EAdapterProduct(EActivityProductCategories.this,
                                            models);
                                    gvSubCategory.setAdapter(adapterProduct);
                                } else {
                                    Product[] models =
                                            gson.fromJson(String.valueOf(
                                                    response.getJSONArray("data")),
                                                    Product[].class);
                                    adapterProduct = new
                                            EAdapterProduct(EActivityProductCategories.this,
                                            models);
                                    gvSubCategory.setAdapter(adapterProduct);
                                    pgcatagory.setVisibility(View.GONE);
                                    (findViewById(R.id.animProductEmpty)).setVisibility(View.VISIBLE);

                                    Toast.makeText(EActivityProductCategories.this, "No dtaa", Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    pgcatagory.setVisibility(View.INVISIBLE);
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {

        }

    }

    private void getdatafromcatagory() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                    Request.Method.GET
                    , ECONSTANT.URL_CATAGORIES, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            try {
                                Category[] models =
                                        gson.fromJson(String.valueOf(
                                                response.getJSONArray("data")),
                                                Category[].class);
                                eAdapterCategory = new
                                        EAdapterCategory(EActivityProductCategories.this,
                                        models);
                                lvCatagories.setAdapter(eAdapterCategory);
                                product_id= models[0].getCategory_id();
                                getdatafromProducts(product_id);


                                lvCatagories.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        (findViewById(R.id.animProductEmpty)).setVisibility(View.GONE);
                                        pgcatagory.setVisibility(View.VISIBLE);
                                        final Category model = eAdapterCategory.getItem(position);
                                        ECONSTANT.cid = model.getCategory_id();
                                        int newId = FastSave.getInstance().getInt(ECONSTANT.CAT_ID_KEY, 0);
                                        if (newId != ECONSTANT.cid) {
                                            FastSave.getInstance().saveInt(ECONSTANT.CAT_ID_KEY, ECONSTANT.cid);
                                            getdatafromProducts(ECONSTANT.cid);
                                        } else {

                                            pgcatagory.setVisibility(View.INVISIBLE);
                                        }
                                        adapterProduct.notifyDataSetInvalidated();
                                        adapterProduct.notifyDataSetChanged();

                                        Log.e(TAG, "onItemClick: " + model.getCategory_id());

                                    }
                                });
                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.eactivity_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_Cart) {
            startActivity(new Intent(EActivityProductCategories.this,
                    EActivityMyCart.class));
            finish();
        }
        return true;
    }

}