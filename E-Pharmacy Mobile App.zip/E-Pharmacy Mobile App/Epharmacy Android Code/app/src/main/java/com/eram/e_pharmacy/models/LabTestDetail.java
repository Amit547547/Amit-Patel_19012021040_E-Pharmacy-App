package com.eram.e_pharmacy.models;

import java.io.Serializable;

public class LabTestDetail implements Serializable {
    private int id, price;
    private String image, title;

    public LabTestDetail(int id, int price, String image, String title) {
        this.id = id;
        this.price = price;
        this.image = image;
        this.title = title;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
