package com.eram.e_pharmacy.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.adapters.EAdapterLabTest;
import com.eram.e_pharmacy.models.LabTestDetail;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONObject;

public class EActivityLabTestCategory extends AppCompatActivity {
    private ListView lvLabTest;
    private String TAG = "TAG";
    private int labtest_id;
    private LottieAnimationView animLabTest;
    private EAdapterLabTest eAdapterLabTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_test_category);
        try {
            Log.e(TAG, "onCreate: ");
            animLabTest=findViewById(R.id.animLabTest);
            lvLabTest = findViewById(R.id.lvLabTest);
            lvLabTest.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    LabTestDetail model = eAdapterLabTest.getItem(position);
                    labtest_id = model.getId();
                    Intent intent = new Intent(
                            EActivityLabTestCategory.this,
                            EActivityLabTestDetail.class);
                    intent.putExtra(ECONSTANT.LABTEST_ID,labtest_id);
                    startActivity(intent);
                }
            });
            animLabTest.setAnimation(R.raw.loading);
            getfromlabtest();
        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }
    }

    private void getfromlabtest() {
        try {
            JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_LAB_TEST,
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            try {
                                if (response.getBoolean("status")) {
                                    LabTestDetail[] models = gson.fromJson(String.valueOf(
                                            response.getJSONArray("data")),
                                            LabTestDetail[].class);
                                    eAdapterLabTest = new EAdapterLabTest(
                                            EActivityLabTestCategory.this,
                                            models);
                                    animLabTest.setVisibility(View.GONE);
                                    lvLabTest.setAdapter(eAdapterLabTest);
                                } else {
                                    LabTestDetail[] models = gson.fromJson(String.valueOf(
                                            response.getJSONArray("data")),
                                            LabTestDetail[].class);
                                    eAdapterLabTest = new EAdapterLabTest(
                                            EActivityLabTestCategory.this,

                                            models);
                                    animLabTest.setVisibility(View.VISIBLE);

                                    lvLabTest.setAdapter(eAdapterLabTest);
                                    animLabTest.setAnimation(R.raw.no_test);

                                }
                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(objectRequest);
        } catch (Exception e) {
            Log.e(TAG, "getfromlabtest: " + e.toString());
        }
    }
}
