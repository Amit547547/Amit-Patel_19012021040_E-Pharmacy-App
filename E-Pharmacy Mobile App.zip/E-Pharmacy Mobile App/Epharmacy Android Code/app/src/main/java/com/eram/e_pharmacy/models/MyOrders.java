package com.eram.e_pharmacy.models;

public class MyOrders {
    int id,price,user_id;

    private String 	name,email,contact_no,address,image,status, p_time;

    public MyOrders(int id, int price, int user_id, String name, String email, String contact_no, String address, String image, String status, String p_time) {
        this.id = id;
        this.price = price;
        this.user_id = user_id;
        this.name = name;
        this.email = email;
        this.contact_no = contact_no;
        this.address = address;
        this.image = image;
        this.status = status;
        this.p_time = p_time;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getP_time() {
        return p_time;
    }

    public void setP_time(String p_time) {
        this.p_time = p_time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
