package com.eram.e_pharmacy.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.adapters.EAdapterOrders;
import com.eram.e_pharmacy.models.MyOrders;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONObject;

public class EActivityMyOrders extends AppCompatActivity {
    private static final String TAG = "TAG";
    ListView lvOrders;
    LottieAnimationView animOrderEmpty;
    private EAdapterOrders adapterOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);
        try {
            lvOrders = findViewById(R.id.lvOrders);
            animOrderEmpty = findViewById(R.id.animOrder);

            lvOrders.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    MyOrders orders = adapterOrders.getItem(position);
                    Intent intent = new Intent(EActivityMyOrders.this,
                            EActivityTrackOrder.class);
                    intent.putExtra("STATUS", orders.getStatus());
                    startActivity(intent);

                }
            });

            ((CardView) findViewById(R.id.cvOOrders)).setCardBackgroundColor(Color.parseColor("#7C4DFF"));
            ((TextView) findViewById(R.id.tvOOrder)).setTextColor(Color.parseColor("#ffffff"));
            getProductOrders();
            ((CardView) findViewById(R.id.cvOPrescription)).setCardBackgroundColor(Color.parseColor("#ffffff"));
            ((TextView) findViewById(R.id.tvOPrescriptions)).setTextColor(Color.parseColor("#4D4D4D"));

            ((CardView) findViewById(R.id.cvOLabTest)).setCardBackgroundColor(Color.parseColor("#ffffff"));
            ((TextView) findViewById(R.id.tvOLabTest)).setTextColor(Color.parseColor("#4D4D4D"));

            findViewById(R.id.cvOOrders).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TextView tvOrder = findViewById(R.id.tvOOrder);
                    if (tvOrder.getCurrentTextColor() != Color.parseColor("#ffffff")) {
                        getProductOrders();
                    }

                    ((CardView) findViewById(R.id.cvOOrders)).setCardBackgroundColor(Color.parseColor("#7C4DFF"));
                    ((TextView) findViewById(R.id.tvOOrder)).setTextColor(Color.parseColor("#ffffff"));

                    ((CardView) findViewById(R.id.cvOPrescription)).setCardBackgroundColor(Color.parseColor("#ffffff"));
                    ((TextView) findViewById(R.id.tvOPrescriptions)).setTextColor(Color.parseColor("#4D4D4D"));

                    ((CardView) findViewById(R.id.cvOLabTest)).setCardBackgroundColor(Color.parseColor("#ffffff"));
                    ((TextView) findViewById(R.id.tvOLabTest)).setTextColor(Color.parseColor("#4D4D4D"));

                }
            });
            findViewById(R.id.cvOPrescription).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TextView tvOPrescriptions = findViewById(R.id.tvOPrescriptions);
                    if (tvOPrescriptions.getCurrentTextColor() != Color.parseColor("#ffffff")) {
                        getdatafromorders();

                    }
                    ((CardView) findViewById(R.id.cvOPrescription)).setCardBackgroundColor(Color.parseColor("#7C4DFF"));
                    tvOPrescriptions.setTextColor(Color.parseColor("#ffffff"));
                    ((CardView) findViewById(R.id.cvOOrders)).setCardBackgroundColor(Color.parseColor("#ffffff"));
                    ((TextView) findViewById(R.id.tvOOrder)).setTextColor(Color.parseColor("#4D4D4D"));

                    ((CardView) findViewById(R.id.cvOLabTest)).setCardBackgroundColor(Color.parseColor("#ffffff"));
                    ((TextView) findViewById(R.id.tvOLabTest)).setTextColor(Color.parseColor("#4D4D4D"));

                }
            });
            findViewById(R.id.cvOLabTest).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TextView tvOLabTest = findViewById(R.id.tvOLabTest);
                    if (tvOLabTest.getCurrentTextColor() != Color.parseColor("#ffffff")) {
                        getLabTestOrders();

                    }
                    ((CardView) findViewById(R.id.cvOLabTest)).setCardBackgroundColor(Color.parseColor("#7C4DFF"));
                    tvOLabTest.setTextColor(Color.parseColor("#ffffff"));

                    ((CardView) findViewById(R.id.cvOOrders)).setCardBackgroundColor(Color.parseColor("#ffffff"));
                    ((TextView) findViewById(R.id.tvOOrder)).setTextColor(Color.parseColor("#4D4D4D"));

                    ((CardView) findViewById(R.id.cvOPrescription)).setCardBackgroundColor(Color.parseColor("#ffffff"));
                    ((TextView) findViewById(R.id.tvOPrescriptions)).setTextColor(Color.parseColor("#4D4D4D"));

                }
            });

        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }
    }

    private void getLabTestOrders() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_GET_LABTEST_ORDER + ECONSTANT.logedUser.getId(),
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            try {

                                if (response.getBoolean("status")) {
                                    (findViewById(R.id.rlOrder)).setVisibility(View.VISIBLE);
                                    (findViewById(R.id.rlOrderEmpty)).setVisibility(View.GONE);
                                    animOrderEmpty.setVisibility(View.GONE);

                                    MyOrders[] models = gson.fromJson
                                            (String.valueOf(response.getJSONArray("data")), MyOrders[].class);
                                    adapterOrders = new EAdapterOrders(EActivityMyOrders.this,
                                            models);
                                    Log.e(TAG, "onResponse: " + models);
                                    lvOrders.setAdapter(adapterOrders);

                                } else {
                                    (findViewById(R.id.rlOrder)).setVisibility(View.GONE);
                                    (findViewById(R.id.rlOrderEmpty)).setVisibility(View.VISIBLE);
                                }

                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(EActivityMyOrders.this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "getLabTestOrders: " + e.toString());
        }
    }

    private void getProductOrders() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_GET_PRODUCT_ORDER + ECONSTANT.logedUser.getId(),
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            try {

                                if (response.getBoolean("status")) {
                                    (findViewById(R.id.rlOrder)).setVisibility(View.VISIBLE);
                                    (findViewById(R.id.rlOrderEmpty)).setVisibility(View.GONE);
                                    animOrderEmpty.setVisibility(View.GONE);

                                    MyOrders[] models = gson.fromJson
                                            (String.valueOf(response.getJSONArray("data")), MyOrders[].class);
                                    adapterOrders = new EAdapterOrders(EActivityMyOrders.this,
                                            models);
                                    Log.e(TAG, "onResponse: " + models);
                                    lvOrders.setAdapter(adapterOrders);

                                } else {
                                    (findViewById(R.id.rlOrder)).setVisibility(View.GONE);
                                    (findViewById(R.id.rlOrderEmpty)).setVisibility(View.VISIBLE);


                                }

                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "getProductOrders: " + e.toString());
        }
    }

    private void getdatafromorders() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_GET_PRESCRIPTION_ORDER + ECONSTANT.logedUser.getId(),
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            Log.e(TAG, "onResponse: " + response.toString());
                            final Gson gson = new Gson();
                            try {

                                if (response.getBoolean("status")) {
                                    (findViewById(R.id.rlOrder)).setVisibility(View.VISIBLE);
                                    (findViewById(R.id.rlOrderEmpty)).setVisibility(View.GONE);
                                    animOrderEmpty.setVisibility(View.GONE);

                                    MyOrders[] models = gson.fromJson
                                            (String.valueOf(response.getJSONArray("data")), MyOrders[].class);
                                    adapterOrders = new EAdapterOrders(EActivityMyOrders.this,
                                            models);
                                    Log.e(TAG, "onResponse: " + models);
                                    lvOrders.setAdapter(adapterOrders);

                                } else {
                                    (findViewById(R.id.rlOrder)).setVisibility(View.GONE);
                                    (findViewById(R.id.rlOrderEmpty)).setVisibility(View.VISIBLE);


                                }
                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Log.e(TAG, "getdatafromorders : " + e.toString());
        }
    }

}
