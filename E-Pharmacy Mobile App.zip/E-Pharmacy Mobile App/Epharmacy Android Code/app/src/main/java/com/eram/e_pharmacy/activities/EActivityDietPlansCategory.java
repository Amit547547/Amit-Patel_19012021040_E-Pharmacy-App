package com.eram.e_pharmacy.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.adapters.EAdapterDietPlans;
import com.eram.e_pharmacy.models.DietPlanCategory;
import com.eram.e_pharmacy.utilities.ECONSTANT;
import com.eram.e_pharmacy.utilities.MyNetwork;
import com.google.gson.Gson;

import org.json.JSONObject;

public class EActivityDietPlansCategory extends AppCompatActivity {
    private static final String TAG = "TAG";
    private ListView lvEDietCatagories;
    private LottieAnimationView animdietplan;
    private LottieAnimationView animDietLoading;
    private EAdapterDietPlans adapter;
    int dietCat_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_plan_categories);
        try {
            animdietplan = findViewById(R.id.animDietPlan);
            animDietLoading = findViewById(R.id.animDietLoading);
            lvEDietCatagories = findViewById(R.id.lvEDietCatagories);
            animDietLoading.setAnimation(R.raw.loading);
            animDietLoading.setVisibility(View.VISIBLE);
            getdietcatagories();
            lvEDietCatagories.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    DietPlanCategory model = adapter.getItem(position);
                    dietCat_id = model.getId();
                    Intent intent = new Intent(EActivityDietPlansCategory.this,
                            EActivityDietPlanDetail.class);
                    intent.putExtra(ECONSTANT.CATID,dietCat_id);
                    startActivity(intent);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }
    }

    private void getdietcatagories() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                    ECONSTANT.URL_DIETcAATGORIES_ECOM, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e(TAG, "onResponse: " + response);
                            final Gson gson = new Gson();
                            try {
                                if (response.getBoolean("status")) {
                                    animDietLoading.setVisibility(View.GONE);
                                    DietPlanCategory[] model = gson.fromJson(String.valueOf(
                                            response.getJSONArray("data")),
                                            DietPlanCategory[].class);
                                    adapter = new
                                            EAdapterDietPlans(
                                            EActivityDietPlansCategory.this,
                                            model);
                                    lvEDietCatagories.setAdapter(adapter);
                                } else {
                                    DietPlanCategory[] model = gson.fromJson(String.valueOf(
                                            response.getJSONArray("data")),
                                            DietPlanCategory[].class);
                                    adapter = new
                                            EAdapterDietPlans(
                                            EActivityDietPlansCategory.this,
                                            model);
                                    animdietplan.setAnimation(R.raw.no_test);
                                    animdietplan.setVisibility(View.VISIBLE);
                                    animDietLoading.setVisibility(View.GONE);

                                    lvEDietCatagories.setAdapter(adapter);

                                }
                            } catch (Exception e) {
                                Log.e(TAG, "onResponse: " + e.toString());
                            }

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: " + error.toString());
                }
            });
            MyNetwork.getInstance(this).addToRequestQueue(jsonObjectRequest);


        } catch (Exception e) {
            Log.e(TAG, "getdietcatagories: " + e.toString());
        }
    }

}
