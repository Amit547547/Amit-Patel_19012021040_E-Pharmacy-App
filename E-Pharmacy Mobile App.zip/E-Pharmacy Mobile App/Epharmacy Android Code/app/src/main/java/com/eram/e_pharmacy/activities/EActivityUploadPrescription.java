package com.eram.e_pharmacy.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.eram.e_pharmacy.R;
import com.eram.e_pharmacy.utilities.ECONSTANT;

public class EActivityUploadPrescription extends AppCompatActivity {

    private static final String TAG = "TAG";
    private LinearLayout llOpenCamera, llOpenGallery;
    private static final int pic_id = 123;
    private ImageView imageView1, ivCamera;
    private Button btn;
    private static final int GALLERY_REQUEST_CODE = 122;
    private Intent intent;
    public static Uri selectedImage = null;
    public static Bitmap photo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_prescription);
        try {

            ivCamera = findViewById(R.id.ivCamera);
            llOpenCamera = findViewById(R.id.llOpenCamera);
            llOpenGallery = findViewById(R.id.llOpenGallery);
            llOpenCamera.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent camera_intent
                                = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                        startActivityForResult(camera_intent, pic_id);
                    } catch (Exception ex) {
                        Log.e(TAG, "onClick: EXP: " + ex.toString());
                    }
                }
            });

            llOpenGallery.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_PICK);
                        intent.setType("image/*");
                        String[] mimeTypes = {"image/jpeg", "image/png"};
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
                        startActivityForResult(intent, GALLERY_REQUEST_CODE);
                    } catch (Exception e) {
                        Log.e(TAG, "onClick: " + e.toString());
                    }
                }
            });


        } catch (Exception e) {
            Log.e(TAG, "onCreate: " + e.toString());
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Intent intent;
        if (resultCode == Activity.RESULT_OK)
            switch (requestCode) {
                case GALLERY_REQUEST_CODE:
                    selectedImage = data.getData();
                     intent  = new Intent(EActivityUploadPrescription.this, EActivityOrderDeliveryDetail.class);
                    intent.putExtra(ECONSTANT.KEY_ORDER_TYPE,ECONSTANT.ORDER_TYPE_PRESCRIPTION);
                    startActivity(intent);
                    break;
                case pic_id:
                    photo = (Bitmap) data.getExtras().get("data");
                    selectedImage = data.getData();
                     intent  = new Intent(EActivityUploadPrescription.this, EActivityOrderDeliveryDetail.class);
                    intent.putExtra(ECONSTANT.KEY_ORDER_TYPE,ECONSTANT.ORDER_TYPE_PRESCRIPTION);
                    startActivity(intent);

                    break;
            }

    }

}
