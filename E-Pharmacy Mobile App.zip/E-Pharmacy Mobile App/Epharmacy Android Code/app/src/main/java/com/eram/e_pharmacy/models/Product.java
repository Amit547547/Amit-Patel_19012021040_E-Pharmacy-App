package com.eram.e_pharmacy.models;

public class Product {
    private int p_id,category_id,p_price,p_sale,p_quantity,offer_price;
    private  String p_title,p_description,p_image;

    public Product(int p_id, int category_id, int p_price, int p_sale, int p_quantity, int offer_price, String p_title, String p_description, String p_image) {
        this.p_id = p_id;
        this.category_id = category_id;
        this.p_price = p_price;
        this.p_sale = p_sale;
        this.p_quantity = p_quantity;
        this.offer_price = offer_price;
        this.p_title = p_title;
        this.p_description = p_description;
        this.p_image = p_image;
    }

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public int getP_price() {
        return p_price;
    }

    public void setP_price(int p_price) {
        this.p_price = p_price;
    }

    public int getP_sale() {
        return p_sale;
    }

    public void setP_sale(int p_sale) {
        this.p_sale = p_sale;
    }

    public int getP_quantity() {
        return p_quantity;
    }

    public void setP_quantity(int p_quantity) {
        this.p_quantity = p_quantity;
    }

    public int getOffer_price() {
        return offer_price;
    }

    public void setOffer_price(int offer_price) {
        this.offer_price = offer_price;
    }

    public String getP_title() {
        return p_title;
    }

    public void setP_title(String p_title) {
        this.p_title = p_title;
    }

    public String getP_description() {
        return p_description;
    }

    public void setP_description(String p_description) {
        this.p_description = p_description;
    }

    public String getP_image() {
        return p_image;
    }

    public void setP_image(String p_image) {
        this.p_image = p_image;
    }
}

